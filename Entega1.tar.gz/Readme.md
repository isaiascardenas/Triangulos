# Entrega 1:

El archivo Entrega1.java contiene el bloque principal que instancia las clases en los archivos Iterativo.java y Recursivo.java. Al ejecutar el programa se le solicitará al usuario que ingrese el método por el cual resolver el problema y el medio por el cual se ingresarán los datos.

* Métodos válidos:

	** Recursivo

	** Iterativo

* Ingreso de datos:

	** Tipeo linea a linea

	** Lectura de archivo

En caso de que el usuario seleccione el tipeo linea a linea, deberá ingresar la cantidad de filas del triángulo y luego tipear linea a linea las filas del triángulo desde la fila más larga a la más corta.

En caso de que el usuario seleccione la lectura de archivos, el programa pedirá el ingreso del nombre del archivo el cual no debe tener la extensión (.txt). El achivo debe estar en la misma carpeta que el archivo ejecutable y la primera linea debe ser la cantidad de filas del triángulo.

La entrega contiene 5 archivos de prueba a modo de ejemplo de la ejecución del programa, se adjuntan los resultados entregados por el programa según los archivos de prueba:

* prueba1.txt : El triángulo más grande posee un área de: 9
* prueba2.txt : El triángulo más grande posee un área de: 9
* prueba3.txt : El triángulo más grande posee un área de: 9
* prueba4.txt : El triángulo más grande posee un área de: 4
* prueba5.txt : El triángulo más grande posee un área de: 9